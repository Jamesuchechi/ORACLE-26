import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Swords, Shield, Zap, TrendingUp, CloudRain, MapPin, Activity, AlertTriangle } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { getFlagUrl } from '../utils/flags';

const MatchPredictor = ({ rankings, venues, onPredict }) => {
  const [team1, setTeam1] = useState('');
  const [team2, setTeam2] = useState('');
  const [venue, setVenue] = useState('MetLife Stadium');
  const [prediction, setPrediction] = useState(null);
  const [simulating, setSimulating] = useState(false);
  const [weights, setWeights] = useState({
    sports: 0.4,
    markets: 0.25,
    finance: 0.15,
    climate: 0.1,
    social: 0.1
  });

  const handleSimulate = async () => {
    if (!team1 || !team2 || team1 === team2) return;
    setSimulating(true);
    // Don't clear prediction immediately to allow comparison
    const res = await onPredict(team1, team2, venue, weights);
    setPrediction(res);
    setSimulating(false);
  };

  // Re-simulate when weights change and we already have a prediction
  useEffect(() => {
    if (prediction && !simulating) {
      handleSimulate();
    }
  }, [weights]);

  const handleWeightChange = (key, val) => {
    setWeights(prev => ({ ...prev, [key]: parseFloat(val) }));
  };

  const getTeam = (name) => rankings.find(r => r.subject === name);

  return (
    <div className="terminal-card bg-bg1/40 border-border space-y-8">
      <div className="flex justify-between items-center">
        <h3 className="text-[10px] font-mono font-bold text-muted tracking-[0.2em] uppercase flex items-center gap-2">
          <Swords size={12} className="text-amber" /> Tactical Matchup Predictor
        </h3>
        
        {prediction?.market_context?.is_upset_alert && (
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="flex items-center gap-2 px-3 py-1 rounded-full bg-red/20 border border-red/40 text-red text-[10px] font-bold uppercase tracking-widest animate-pulse"
          >
            <AlertTriangle size={12} />
            Upset Alert: {prediction.market_context.divergence_driver} Divergence
          </motion.div>
        )}

        <div className="flex items-center gap-2 text-[9px] font-mono text-muted">
          <MapPin size={10} />
          <select 
            value={venue}
            onChange={(e) => setVenue(e.target.value)}
            className="bg-transparent border-none focus:ring-0 text-foreground/50 cursor-pointer max-w-[140px] sm:max-w-[250px] truncate"
          >
            {venues.map(v => <option key={v.venue} value={v.venue} className="bg-bg1">{v.city} ({v.venue})</option>)}
          </select>
        </div>
      </div>

      {/* Signal Weight Sensitivity Sliders */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 p-4 rounded-xl bg-[var(--card-bg)] border border-border">
        {Object.entries(weights).map(([key, val]) => (
          <div key={key} className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-[8px] font-mono text-muted uppercase tracking-widest">{key}</label>
              <span className="text-[8px] font-mono text-amber">{(val * 100).toFixed(0)}%</span>
            </div>
            <input 
              type="range" 
              min="0" max="1" step="0.05" 
              value={val} 
              onChange={(e) => handleWeightChange(key, e.target.value)}
              className="w-full h-1 bg-foreground/30 [.light_&]:bg-black/60 rounded-lg appearance-none cursor-pointer accent-amber"
            />
          </div>
        ))}
      </div>

      <div className="flex flex-col lg:grid lg:grid-cols-11 gap-6 lg:gap-4 items-center">
        {/* Team 1 Selection */}
        <div className="w-full lg:col-span-5 space-y-4">
          <div className="p-4 rounded-xl bg-[var(--card-bg)] border border-border text-center flex flex-col items-center">
            {team1 && (
              <img 
                src={getFlagUrl(team1)} 
                alt={team1} 
                className="w-12 h-8 mb-4 rounded shadow-lg border border-border"
              />
            )}
            <select 
              value={team1} 
              onChange={(e) => setTeam1(e.target.value)}
              className="w-full bg-transparent border-none text-xl font-bold text-center focus:ring-0 appearance-none truncate"
            >
              <option value="" className="bg-bg1 text-muted">Select Team A</option>
              {rankings.map(r => <option key={r.subject} value={r.subject} className="bg-bg1">{r.subject}</option>)}
            </select>
            <p className="text-[10px] font-mono text-muted uppercase mt-2">Home / Seed 1</p>
          </div>
          
          {getTeam(team1) && <SignalStats team={getTeam(team1)} />}
        </div>

        {/* VS Divider */}
        <div className="hidden lg:flex lg:col-span-1 flex-col items-center">
           <div className="h-12 w-[1px] bg-foreground/20 mb-4" />
           <div className="w-8 h-8 rounded-full border border-border flex items-center justify-center text-[10px] font-mono text-muted">VS</div>
           <div className="h-12 w-[1px] bg-foreground/20 mt-4" />
        </div>

        <div className="lg:hidden flex items-center justify-center py-2">
          <div className="h-[1px] flex-1 bg-foreground/20" />
          <div className="px-4 text-[10px] font-mono text-foreground/10">VERSUS</div>
          <div className="h-[1px] flex-1 bg-foreground/20" />
        </div>

        {/* Team 2 Selection */}
        <div className="w-full lg:col-span-5 space-y-4">
          <div className="p-4 rounded-xl bg-[var(--card-bg)] border border-border text-center flex flex-col items-center">
            {team2 && (
              <img 
                src={getFlagUrl(team2)} 
                alt={team2} 
                className="w-12 h-8 mb-4 rounded shadow-lg border border-border"
              />
            )}
            <select 
              value={team2} 
              onChange={(e) => setTeam2(e.target.value)}
              className="w-full bg-transparent border-none text-xl font-bold text-center focus:ring-0 appearance-none truncate"
            >
              <option value="" className="bg-bg1 text-muted">Select Team B</option>
              {rankings.map(r => <option key={r.subject} value={r.subject} className="bg-bg1">{r.subject}</option>)}
            </select>
            <p className="text-[10px] font-mono text-muted uppercase mt-2">Away / Seed 2</p>
          </div>
          {getTeam(team2) && <SignalStats team={getTeam(team2)} reverse />}
        </div>
      </div>

      <div className="flex justify-center">
        <button 
          onClick={handleSimulate}
          disabled={!team1 || !team2 || simulating}
          className={`px-8 py-3 rounded-lg font-mono text-xs font-bold tracking-[0.2em] uppercase transition-all flex items-center gap-3
            ${!team1 || !team2 ? 'bg-foreground/20 text-muted cursor-not-allowed' : 'bg-amber text-bg hover:scale-105 active:scale-95'}
          `}
        >
          {simulating ? <div className="w-4 h-4 border-2 border-bg/20 border-t-bg rounded-full animate-spin" /> : <Zap size={14} />}
          {simulating ? 'Synthesizing...' : 'Run Simulation'}
        </button>
      </div>

      {/* Prediction Result Overlay */}
      <AnimatePresence>
        {prediction && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="pt-8 border-t border-border"
          >
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 lg:gap-6">
              <ProbCard 
                label="CONFLUX WIN" 
                team={team1} 
                prob={prediction.win_prob} 
                marketProb={prediction.market_context?.team1_prob}
                color="text-teal" 
              />
              <ProbCard label="DRAW" team="NEUTRAL" prob={prediction.draw_prob} color="text-muted" />
              <ProbCard 
                label="CONFLUX WIN" 
                team={team2} 
                prob={prediction.loss_prob} 
                marketProb={prediction.market_context?.team2_prob}
                color="text-blue" 
              />
            </div>
            
            <div className="mt-8 grid grid-cols-1 gap-4">
               <div className="p-4 rounded-lg bg-bg2/50 border border-border">
                  <div className="flex items-center gap-2 mb-3">
                     <Activity size={14} className="text-amber" />
                     <h4 className="text-[10px] font-mono font-bold text-muted uppercase tracking-widest">AI Tactical Analysis</h4>
                  </div>
                  <div className="text-[11px] text-foreground/60 leading-relaxed italic prose-xs prose-invert">
                    <ReactMarkdown>{prediction.intelligence_report}</ReactMarkdown>
                  </div>
               </div>

               <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {Object.entries(prediction?.advantages || {}).map(([key, team]) => (
                    <div key={key} className="p-3 rounded-lg border border-border bg-[var(--card-bg)]">
                       <p className="text-[8px] font-mono text-muted uppercase mb-1">{key.replace('_', ' ')}</p>
                       <p className="text-[10px] font-bold text-teal flex items-center gap-2 truncate">
                         <Shield size={10} className="shrink-0" /> {team}
                       </p>
                    </div>
                  ))}
               </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const SignalStats = ({ team, reverse }) => (
  <div className={`space-y-2 ${reverse ? 'text-right' : 'text-left'}`}>
    <div className={`flex items-center gap-2 text-[9px] font-mono text-foreground/30 ${reverse ? 'flex-row-reverse' : ''}`}>
       <TrendingUp size={10} />
       <span>Sports: {((team?.signal_breakdown?.sports || 0) * 100).toFixed(0)}%</span>
    </div>
    <div className={`flex items-center gap-2 text-[9px] font-mono text-foreground/30 ${reverse ? 'flex-row-reverse' : ''}`}>
       <CloudRain size={10} />
       <span>Climate: {((team?.signal_breakdown?.climate || 0) * 100).toFixed(0)}%</span>
    </div>
  </div>
);

const ProbCard = ({ label, team, prob, color }) => (
  <div className="text-center p-4 rounded-xl bg-[var(--card-bg)] border border-border">
    {team !== 'NEUTRAL' && (
      <img 
        src={getFlagUrl(team)} 
        alt={team} 
        className="w-8 h-5 mx-auto mb-3 rounded-sm shadow-sm border border-border"
      />
    )}
    <p className="text-[9px] font-mono text-muted uppercase tracking-widest mb-1">{team}</p>
    <p className={`text-2xl lg:text-3xl font-mono font-bold ${color}`}>{(prob * 100).toFixed(1)}%</p>
    <p className="text-[9px] font-bold text-foreground/10 uppercase mt-1">{label}</p>
  </div>
);

export default MatchPredictor;
